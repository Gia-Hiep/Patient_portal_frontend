// helpers.js - utility helper functions
