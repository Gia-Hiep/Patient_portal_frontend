// constants.js - store global constants
